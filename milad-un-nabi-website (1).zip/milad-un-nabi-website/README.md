# Mehfil-e-Eid Milad-un-Nabi — Official Digital Archive

The official website for **milad-un-nabi.com** — a digital archive for the
annual Mehfil-e-Eid Milad-un-Nabi founded by Al-Haj Mian Muhammad Suleman
(R.A) at National Pipe, Lahore. Static HTML5 / CSS3 / vanilla JavaScript
only — no framework, no build step required to run it, and no server.

## Quick start

**Just want to preview it?** Open `index.html` in a browser, or run a local
static server from this folder, e.g. `npx serve .` or `python3 -m http.server`.

**Deploying:**
- **GitHub Pages** — push this folder to a repo and enable Pages on the
  `main` branch (root).
- **Vercel** — import the repo, framework preset "Other", no build command,
  output directory `/`.

Either way, `index.html` at the project root is the homepage.

## Editing content

Almost everything on the site — the founder's details, the next Mehfil
date, contact numbers, the timeline, pillars, videos, gallery, FAQs, news
articles — lives in **one file**:

```
build/content.js
```

Edit that file, then rebuild the static HTML with:

```bash
node build/build.js
```

This regenerates every `.html` page, `sitemap.xml`, `robots.txt`, and the
search index from the templates in `build/pages/`. It has **zero npm
dependencies** — plain Node.js is enough (Node 16+).

### Updating the countdown each year

The Mehfil follows the Islamic lunar date (12 Rabi-ul-Awwal), so its
Gregorian date moves earlier by ~10–11 days every year — there's no
reliable formula for it. Once next year's date is confirmed, update
`site.nextEvent` in `build/content.js`:

```js
nextEvent: {
  isoDatePKT: "2026-09-05T18:00:00+05:00", // update this each year
  dateLabel: "Saturday, 5 September 2026",
  timeLabel: "6:00 PM onward",
},
```

then run `node build/build.js` again.

### Adding real photos, videos, scholars, Na'at Khawans

To keep the archive honest, placeholder entries are clearly marked rather
than invented:

- **Gallery** (`gallery` array in `content.js`): add `{ img: "filename",
  era: "1980s", caption: "..." }` and drop the matching image into
  `/images/`.
- **Videos** (`videos` array): add `{ id: "youtube-video-id", title, year,
  desc }`. Thumbnails are pulled automatically from YouTube.
- **Scholars / Na'at Khawans**: replace the placeholder entries in the
  `scholars` / `naatKhawans` arrays with real names, roles and short bios.
- **News & Articles**: add an entry to the `news` array; a page is
  generated automatically at `/pages/news-{slug}.html`.

## Project structure

```
index.html            Homepage (must stay at root for GitHub/Vercel)
404.html              Not-found page
robots.txt            Points crawlers to sitemap.xml
sitemap.xml           XML sitemap — kept at root; see note below
site.webmanifest       PWA manifest

pages/                 All inner pages (about, founder, legacy, timeline,
                        programme, scholars, naat-khawans, gallery, videos,
                        seven-umrah, community, news + articles, faqs,
                        contact, privacy, terms)
sitemap/index.html      Human-readable sitemap page (kept separate from
                        sitemap.xml — see note below)

css/                   fonts.css, base.css (tokens/reset/type), 
                        components.css, widgets.css, pages.css
js/                    main.js, countdown.js, gallery.js, video.js,
                        faq.js, timeline.js, search.js — all vanilla JS
fonts/                 Self-hosted woff2 files (Fraunces, Inter,
                        Noto Naskh Arabic) — no third-party font requests
images/                Founder portrait (restored + responsive sizes)
assets/patterns/       Generated Islamic geometric SVGs (the countdown
                        medallion rings, divider motif, background
                        texture, and the site mark/favicon)
assets/search-index.json   Generated search index (do not hand-edit)
videos/                Reserved for future locally-hosted video posters

build/                 The static site generator (Node, zero dependencies)
  content.js            <- all editable site content lives here
  layout.js              Shared <head>, nav, footer, schema, page wrapper
  components.js           Reusable HTML snippets (cards, countdown, etc.)
  icons.js                 Inline SVG icon set
  pages/*.js                 One file per page/template
  tools/restore_image.py      The script used to restore the founder photo
```

**Why is `sitemap.xml` at the root but the human sitemap page lives in
`/sitemap/`?** Per the sitemap protocol, a sitemap file can only list URLs
at or below its own folder — since this site's URLs span the whole
domain, `sitemap.xml` has to live at the root. The `/sitemap/` folder
holds the friendly, browsable HTML version instead.

## Design system

- **Palette**: Emerald `#0B6B43`, Deep Green `#0A2E1F`, Ivory `#FBF7EE`,
  White, plus a restrained antique gold `#A9812E` for hairline accents —
  see `css/base.css` for the full token list.
- **Type**: Fraunces (display/headings), Inter (UI/body), Noto Naskh
  Arabic (Arabic phrases and honorifics) — all self-hosted.
- **Signature motif**: a hand-generated geometric "shamsa" medallion
  (`assets/patterns/ring-outer.svg` + `ring-inner.svg`), used to frame the
  countdown and as a recurring divider — a nod to the illuminated
  medallions used to mark sacred manuscripts, rather than generic
  decorative patterning.

## Accessibility & performance notes

- Skip-to-content link, semantic landmarks, `aria-current` on nav,
  keyboard-operable lightbox/accordion/search, `prefers-reduced-motion`
  respected throughout.
- YouTube embeds are click-to-load facades (`js/video.js`) — no iframes
  load until a visitor actually presses play.
- Fonts are self-hosted `woff2` with `font-display: swap`; images ship as
  responsive `.jpg`/`.webp` pairs.
- Every page carries Organization + BreadcrumbList schema; the homepage
  adds Event schema, the FAQ page adds FAQPage schema, and news articles
  add Article schema.

## Known placeholders to replace

- **Scholars & Na'at Khawans**: generic placeholder cards until this
  year's names are confirmed.
- **Gallery**: only the founder's portrait is a real photograph today;
  the rest are clearly marked "photograph to be added" tiles by decade.
- **Videos**: two verified real recordings are included; two placeholder
  slots are ready for more YouTube IDs.

None of these are hidden or faked — they're intentionally visible as
placeholders so the archive never claims more history than it currently
holds.
