/*!
 * countdown.js — live countdown to the next Mehfil.
 * The target date is set per year by the organizers (the Mehfil follows the
 * Islamic lunar date of 12 Rabi-ul-Awwal, so it shifts on the Gregorian
 * calendar) and is read from a data-target="ISO date" attribute — see
 * build/content.js -> site.nextEvent, the single place to update it each year.
 * Multiple instances on one page are supported (home widget + full page).
 */
(function () {
  "use strict";

  function pad(n) { return String(n).padStart(2, "0"); }

  function renderInstance(el) {
    var iso = el.getAttribute("data-target");
    if (!iso) return;
    var target = new Date(iso);
    if (isNaN(target.getTime())) return;

    var dayEl = el.querySelector('[data-cd="days"]');
    var hourEl = el.querySelector('[data-cd="hours"]');
    var minEl = el.querySelector('[data-cd="mins"]');
    var secEl = el.querySelector('[data-cd="secs"]');
    var doneEl = el.querySelector("[data-cd-done]");
    var liveEls = el.querySelectorAll(".countdown-grid, .medallion");

    function tick() {
      var now = new Date();
      var diff = target.getTime() - now.getTime();
      if (diff <= 0) {
        if (doneEl) doneEl.hidden = false;
        liveEls.forEach(function (g) { g.style.display = "none"; });
        clearInterval(timer);
        return;
      }
      var s = Math.floor(diff / 1000);
      var days = Math.floor(s / 86400);
      var hours = Math.floor((s % 86400) / 3600);
      var mins = Math.floor((s % 3600) / 60);
      var secs = Math.floor(s % 60);
      if (dayEl) dayEl.textContent = pad(days);
      if (hourEl) hourEl.textContent = pad(hours);
      if (minEl) minEl.textContent = pad(mins);
      if (secEl) secEl.textContent = pad(secs);
    }

    tick();
    var timer = setInterval(tick, 1000);
  }

  function init() {
    document.querySelectorAll("[data-countdown]").forEach(renderInstance);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
