/*!
 * gallery.js — era filter chips + accessible lightbox for the photo gallery.
 */
(function () {
  "use strict";

  var grid = document.querySelector("[data-gallery-grid]");
  if (!grid) return;

  var filterBar = document.querySelector("[data-gallery-filters]");
  var items = Array.prototype.slice.call(grid.querySelectorAll("[data-gallery-item]"));
  var lightbox = document.querySelector("[data-lightbox]");
  var lbImg = lightbox ? lightbox.querySelector("img") : null;
  var lbCaption = lightbox ? lightbox.querySelector("figcaption") : null;
  var currentIndex = 0;

  if (filterBar) {
    filterBar.addEventListener("click", function (e) {
      var btn = e.target.closest("button[data-filter]");
      if (!btn) return;
      filterBar.querySelectorAll("button").forEach(function (b) { b.classList.remove("is-active"); });
      btn.classList.add("is-active");
      var filter = btn.getAttribute("data-filter");
      items.forEach(function (item) {
        var era = item.getAttribute("data-era");
        var show = filter === "all" || era === filter;
        item.style.display = show ? "" : "none";
      });
    });
  }

  function openAt(index) {
    var visible = items.filter(function (item) { return item.style.display !== "none"; });
    var item = visible[index] || items[index];
    if (!item || !lightbox) return;
    var full = item.getAttribute("data-full") || item.querySelector("img").src;
    var caption = item.getAttribute("data-caption") || "";
    currentIndex = items.indexOf(item);
    if (lbImg) { lbImg.src = full; lbImg.alt = caption; }
    if (lbCaption) lbCaption.textContent = caption;
    lightbox.classList.add("is-open");
    document.body.style.overflow = "hidden";
    lightbox.querySelector(".lightbox-close").focus();
  }

  function closeLightbox() {
    if (!lightbox) return;
    lightbox.classList.remove("is-open");
    document.body.style.overflow = "";
  }

  items.forEach(function (item, i) {
    if (item.hasAttribute("data-placeholder")) return;
    item.addEventListener("click", function () { openAt(i); });
    item.setAttribute("tabindex", "0");
    item.setAttribute("role", "button");
    item.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); openAt(i); }
    });
  });

  if (lightbox) {
    lightbox.querySelector(".lightbox-close").addEventListener("click", closeLightbox);
    lightbox.addEventListener("click", function (e) { if (e.target === lightbox) closeLightbox(); });
    var prevBtn = lightbox.querySelector(".lightbox-prev");
    var nextBtn = lightbox.querySelector(".lightbox-next");
    if (prevBtn) prevBtn.addEventListener("click", function () {
      var real = items.filter(function (it) { return !it.hasAttribute("data-placeholder"); });
      var pos = real.indexOf(items[currentIndex]);
      openAt(items.indexOf(real[(pos - 1 + real.length) % real.length]));
    });
    if (nextBtn) nextBtn.addEventListener("click", function () {
      var real = items.filter(function (it) { return !it.hasAttribute("data-placeholder"); });
      var pos = real.indexOf(items[currentIndex]);
      openAt(items.indexOf(real[(pos + 1) % real.length]));
    });
    document.addEventListener("keydown", function (e) {
      if (!lightbox.classList.contains("is-open")) return;
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowRight" && nextBtn) nextBtn.click();
      if (e.key === "ArrowLeft" && prevBtn) prevBtn.click();
    });
  }
})();
