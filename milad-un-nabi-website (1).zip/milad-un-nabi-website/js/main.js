/*!
 * main.js — shared behaviour for every page:
 * sticky nav state, mobile drawer, scroll-reveal, back-to-top,
 * current year, and the WhatsApp/YouTube floating dock.
 * Vanilla JS, no dependencies.
 */
(function () {
  "use strict";

  document.documentElement.classList.remove("no-js");

  /* ---------- Sticky nav shadow state ---------- */
  var nav = document.querySelector(".site-nav");
  if (nav) {
    var onScroll = function () {
      if (window.scrollY > 8) nav.classList.add("is-scrolled");
      else nav.classList.remove("is-scrolled");
    };
    document.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
  }

  /* ---------- Mobile drawer ---------- */
  var toggle = document.querySelector(".nav-toggle");
  var drawer = document.querySelector(".mobile-drawer");
  if (toggle && drawer) {
    toggle.addEventListener("click", function () {
      var open = toggle.getAttribute("aria-expanded") === "true";
      toggle.setAttribute("aria-expanded", String(!open));
      drawer.classList.toggle("is-open", !open);
      document.body.style.overflow = !open ? "hidden" : "";
    });
    drawer.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () {
        toggle.setAttribute("aria-expanded", "false");
        drawer.classList.remove("is-open");
        document.body.style.overflow = "";
      });
    });
  }

  /* ---------- Active nav link (based on current path) ---------- */
  (function markActive() {
    var path = window.location.pathname.replace(/\/index\.html$/, "/");
    var file = path.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-links a, .mobile-drawer a, .nav-more-panel a").forEach(function (a) {
      var href = a.getAttribute("href") || "";
      var hrefFile = href.split("/").pop();
      if (hrefFile && (hrefFile === file || (file === "" && hrefFile === "index.html"))) {
        a.setAttribute("aria-current", "page");
      }
    });
  })();

  /* ---------- Scroll reveal ---------- */
  var revealEls = document.querySelectorAll(".reveal, .reveal-group");
  if ("IntersectionObserver" in window && revealEls.length) {
    var io = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: "0px 0px -60px 0px" }
    );
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("is-visible"); });
  }

  /* ---------- Back to top ---------- */
  var backToTop = document.querySelector(".back-to-top");
  if (backToTop) {
    document.addEventListener(
      "scroll",
      function () {
        backToTop.classList.toggle("is-visible", window.scrollY > 700);
      },
      { passive: true }
    );
    backToTop.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  /* ---------- Footer year ---------- */
  document.querySelectorAll("[data-year]").forEach(function (el) {
    el.textContent = new Date().getFullYear();
  });

  /* ---------- Generic dropdown (nav "More") keyboard support ---------- */
  document.querySelectorAll(".nav-more").forEach(function (item) {
    var link = item.querySelector(":scope > a, :scope > button");
    if (!link) return;
    link.addEventListener("click", function (e) {
      if (window.matchMedia("(hover: none)").matches) {
        e.preventDefault();
        item.classList.toggle("is-open");
        var panel = item.querySelector(".nav-more-panel");
        if (panel) {
          panel.style.opacity = item.classList.contains("is-open") ? "1" : "";
          panel.style.visibility = item.classList.contains("is-open") ? "visible" : "";
        }
      }
    });
  });
})();
