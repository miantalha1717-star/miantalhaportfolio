/*!
 * search.js — lightweight client-side search across page titles/descriptions.
 * Index is generated at build time into /assets/search-index.json.
 */
(function () {
  "use strict";

  var openBtns = document.querySelectorAll("[data-search-open]");
  var overlay = document.querySelector("[data-search-overlay]");
  if (!overlay || !openBtns.length) return;
  var input = overlay.querySelector("input");
  var results = overlay.querySelector("[data-search-results]");
  var closeBtn = overlay.querySelector("[data-search-close]");
  var indexData = null;
  var basePath = (function () {
    // pages/ and sitemap/ are one level deep; index.html is at root.
    var depth = window.location.pathname.split("/").filter(Boolean).length;
    return window.location.pathname.includes("/pages/") || window.location.pathname.includes("/sitemap/") ? "../" : "./";
  })();

  function fetchIndex() {
    if (indexData) return Promise.resolve(indexData);
    return fetch(basePath + "assets/search-index.json")
      .then(function (r) { return r.json(); })
      .then(function (data) { indexData = data; return data; })
      .catch(function () { return []; });
  }

  function render(list) {
    if (!list.length) {
      results.innerHTML = '<div class="search-empty">No pages match your search yet — try a different word.</div>';
      return;
    }
    results.innerHTML = list
      .map(function (p) {
        return (
          '<a href="' + basePath + p.href + '">' +
          '<div class="r-title">' + p.title + "</div>" +
          '<div class="r-desc">' + p.desc + "</div>" +
          "</a>"
        );
      })
      .join("");
  }

  function doSearch(q) {
    fetchIndex().then(function (data) {
      var query = q.trim().toLowerCase();
      if (!query) { render(data.slice(0, 6)); return; }
      var matches = data.filter(function (p) {
        return (p.title + " " + p.desc + " " + (p.keywords || "")).toLowerCase().indexOf(query) !== -1;
      });
      render(matches);
    });
  }

  function open() {
    overlay.classList.add("is-open");
    document.body.style.overflow = "hidden";
    fetchIndex().then(function (data) { render(data.slice(0, 6)); });
    setTimeout(function () { input.focus(); }, 50);
  }
  function close() {
    overlay.classList.remove("is-open");
    document.body.style.overflow = "";
    input.value = "";
  }

  openBtns.forEach(function (b) { b.addEventListener("click", open); });
  if (closeBtn) closeBtn.addEventListener("click", close);
  overlay.addEventListener("click", function (e) { if (e.target === overlay) close(); });
  document.addEventListener("keydown", function (e) {
    if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) { e.preventDefault(); open(); }
    if (e.key === "Escape" && overlay.classList.contains("is-open")) close();
  });
  if (input) input.addEventListener("input", function () { doSearch(input.value); });
})();
