/*!
 * timeline.js — decade filter chips for the full Historical Timeline page.
 */
(function () {
  "use strict";
  var nav = document.querySelector("[data-timeline-nav]");
  var list = document.querySelector("[data-timeline-list]");
  if (!nav || !list) return;
  var entries = Array.prototype.slice.call(list.querySelectorAll("[data-decade]"));

  nav.addEventListener("click", function (e) {
    var btn = e.target.closest("button[data-filter]");
    if (!btn) return;
    nav.querySelectorAll("button").forEach(function (b) { b.classList.remove("is-active"); });
    btn.classList.add("is-active");
    var filter = btn.getAttribute("data-filter");
    entries.forEach(function (entry) {
      var show = filter === "all" || entry.getAttribute("data-decade") === filter;
      entry.style.display = show ? "" : "none";
    });
  });
})();
