/*!
 * video.js — click-to-load YouTube embeds. Cards show a static thumbnail
 * and only inject the real <iframe> on interaction, keeping initial page
 * weight and Lighthouse scores healthy on video-heavy pages.
 */
(function () {
  "use strict";

  function loadVideo(card) {
    var id = card.getAttribute("data-video-id");
    if (!id) return;
    var wrap = card.querySelector(".thumb");
    if (!wrap) return;
    var iframe = document.createElement("iframe");
    iframe.src = "https://www.youtube-nocookie.com/embed/" + id + "?autoplay=1&rel=0";
    iframe.title = card.getAttribute("data-video-title") || "Video";
    iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture";
    iframe.allowFullscreen = true;
    iframe.style.position = "absolute";
    iframe.style.inset = "0";
    iframe.style.width = "100%";
    iframe.style.height = "100%";
    iframe.style.border = "0";
    wrap.innerHTML = "";
    wrap.appendChild(iframe);
  }

  document.querySelectorAll("[data-video-id]").forEach(function (card) {
    card.addEventListener("click", function () { loadVideo(card); });
    card.setAttribute("tabindex", "0");
    card.setAttribute("role", "button");
    card.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); loadVideo(card); }
    });
  });
})();
